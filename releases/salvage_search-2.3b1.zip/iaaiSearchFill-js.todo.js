// "fill out" search sidebar
document.querySelector("#startYearTxt").value = message.year;
document.querySelector("#endYearTxt"  ).value = message.year;
message.makes.forEach(  makeId=>document.querySelector("#cbMk"+makeId).click()   )
message.models.forEach( modelId=>document.querySelector("#cbMd"+modelId).click() )
document.querySelector("#buyerZipCode").value = message.zip;
document.querySelector("#radiusZipcode").selectedIndex = message.radius;